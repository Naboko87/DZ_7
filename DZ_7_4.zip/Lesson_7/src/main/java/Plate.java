public class Plate {
    private int food;
    //private boolean cat.fool;

    public Plate(int food) {
        this.food = food;
    }

    public void decreaseFood(Cat cat) {
        int b = food-cat.appetite;
        if (food<cat.appetite) {
           System.out.println("Not enough food on the plate, "  +  cat.name + "  wants more");
           addFood(cat);
        } else {
            if (b < 0) {
                System.out.println("STOP NOT FOOD");
            } else {
                if (cat.fool == false) {
                    food -= cat.appetite;
                    cat.fool = true;
                    System.out.println("Cat " +  cat.name + " ate .......");
                    System.out.println("Cat " +  cat.name +  " is FOOL: " + cat.fool);
                    System.out.println("Leftover food on the plate: " + food);
                } else {
                    System.out.println("Cat  " +  cat.name + " does not want to eat. He is cat.fool");
                    System.out.println();
                    System.out.println("Leftover food on the plate: " + food);
                }
            }
        }
    }

    public void info() {
            System.out.println("Food in a plate: " + food);

    }

    public void addFood(Cat cat) {
        System.out.println("Leftover food on the plate: " + food);
        food += cat.appetite;
        System.out.println("Add food on the plate: " + food);
        food -= cat.appetite;
        cat.fool = true;
        System.out.println("Cat " +  cat.name + " ate .......");
        System.out.println("Cat " +  cat.name +  " is FOOL: " + cat.fool);
        System.out.println("Leftover food on the plate: " + food);

    }

}

