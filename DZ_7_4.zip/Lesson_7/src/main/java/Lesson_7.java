public class Lesson_7 {


        public static void main(String[] args) {

                Plate plate = new Plate(100);
                plate.info();
                System.out.println();

                Cat[] cats = new Cat[3];
                cats[0] = new Cat("Barsik", 100, false);
                cats[1] = new Cat("Stepa", 10, false);
                cats[2] = new Cat("Murzic", 0, true);

                int b = 0;

                for(int i = 0; i < cats.length; i++) {
                        //System.out.println("name: " + cats[i].name + ";" + " appetite: " + cats[i].appetite + ";" + " fool: " + cats[i].fool + ";" );
                        b = i + 1;

                        plate.decreaseFood(cats[i]);
                        System.out.println();
                }

                //Первый вариант решения без массива
                //Cat cat = new Cat("Barsik", 40, false);
                //cat.catInfo();

                //Plate plate = new Plate(100);
                //plate.info();
                //cat.eat(plate);







    }

}
