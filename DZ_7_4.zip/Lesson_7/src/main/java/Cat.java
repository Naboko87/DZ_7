public class Cat {
    public  String name;
    public  int appetite;
    public  boolean fool;


     public Cat(String name, int appetite, boolean fool) {
            this.name = name;
            this.appetite = appetite;
            this.fool = fool;
        }

    public void catInfo() {
        System.out.println("Name cat:  " + name + ";" + "Appetite cat: " + appetite + ";" + "Fool cat: " + fool + ";");
    }



    //public void eat(Plate p) {
        //p.decreaseFood(appetite);
    //}

}
